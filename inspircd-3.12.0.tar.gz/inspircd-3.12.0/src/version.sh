#!/bin/sh
echo "InspIRCd-3.12.0"
